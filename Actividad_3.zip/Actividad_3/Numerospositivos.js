var num1 = parseFloat(prompt("ingrese el valor inicial:"))
var num2 = parseFloat(prompt("Ingrese el valor final"))
suma=0

console.log ("los numeros comprendidos entre "+num1+" y "+num2+"es")

for (i=num1;i<=num2;i++){console.log(i)}
for (i=num1;i<=num2;i++){suma=sima+i}
console.log ("el valor de la suma es:"+suma)