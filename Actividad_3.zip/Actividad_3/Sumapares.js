var inicio=1
var resultado=0
for(inicio=0;inicio<=50;inicio+=2){
    resultado=resultado+inicio;
    console.log(inicio)
}

console.log(" el total es " + resultado)